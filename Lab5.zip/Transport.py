class Transport:
    def __init__(self):
        self.x, self.y = 0, 0
        self.price = 0
        self.speed = 0
        self.year = 0

    def SetCoords(self, x, y):
        self.x, self.y = x, y
        return self

    def SetPrice(self, price):
        self.price = price
        return self

    def SetSpeed(self, speed):
        self.speed = speed
        return self

    def SetYear(self, year):
        self.year = year
        return self


class Plane(Transport):
    def __init__(self):
        super().__init__()
        self.height = 0
        self.passCount = 0

    def SetHeight(self, height):
        self.height = height
        return self

    def SetPassCount(self, count):
        self.passCount = count
        return self


class Car(Transport):
    def __init__(self):
        super().__init__()


class Boat(Transport):
    def __init__(self):
        super().__init__()
        self.passCount = 0
        self.port = 0

    def SetPassCount(self, count):
        self.passCount = count
        return self

    def SetPort(self, port):
        self.port = port
        return self


def task6_example():
    plane = Plane()
    plane.SetYear(1994).SetSpeed(500).SetPrice(200000).SetCoords(15, 20).SetHeight(2000).SetPassCount(54)
    print(f"Plane year: {plane.year}\tPlane speed: {plane.speed}")
    boat = Boat()
    boat.SetYear(1993).SetSpeed(100).SetPrice(100000).SetCoords(15, 2).SetPort(54).SetPassCount(20)
    print(f"Boat passengers count: {boat.passCount}\tBoat port: {boat.port}")
