class Card:
    def __init__(self, mast, nomer):
        self.mast = mast
        self.nomer = nomer

    def toString(self) -> None:
        print(f"Mast: {self.mast}\tNumber: {self.nomer}")


class Cards:
    def __init__(self):
        self._masts = ["Club", "Diamonds", "Hearts", "Spades"]
        self._cards = ["T", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Joker", "Queen", "King"]
        self._coloda = []
        for m in self._masts:
            for c in self._cards:
                self._coloda.append(Card(m, c))

    def AllCards(self):
        for card in self._coloda:
            card.toString()

    def Shake(self):
        from random import shuffle
        shuffle(self._coloda)

    def GetOneCard(self):
        c = self._coloda[0]
        self._coloda.remove(c)
        return c

    def GetSixCards(self):
        cards = self._coloda[0:6]
        for index in range(6):
            self._coloda.remove(self._coloda[index])
        return cards

    def GetByIndex(self, index):
        return self._coloda[index]


def task4_example():
    c = Cards()
    c.Shake()
    d: Card = c.GetOneCard()
    d.toString()
    cards = c.GetSixCards()
    for card in cards:
        card.toString()