class Vocabulary:
    def __init__(self):
        self.words = {}

    def AddWord(self, word: str, translations: list):
        self.words[word] = translations

    def GetWordTranslation(self, word):
        trans = self.words[word]
        print(f"\n===\nWord: {word}\nPossible translations: ", end='')
        print(*trans)
        print("===")


def task5_example():
    v = Vocabulary()
    v.AddWord("Bebra", ["Бебра", "Стол"])
    v.GetWordTranslation("Bebra")
