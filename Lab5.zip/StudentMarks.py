class StudentMarks:
    def __init__(self, student_name: str, dictionary: dict):
        self.name = student_name
        self.dictionary = dictionary
        self.labs = []
        self.ind = 0

    def AddLab(self, mark):
        max_mark = self.dictionary["max_mark_for_lab"]
        mark = max_mark if mark > max_mark else mark
        self.labs.append(mark)

    def AddInd(self, mark):
        max_mark = self.dictionary["max_mark_for_ind"]
        mark = max_mark if mark > max_mark else mark
        self.ind = mark

    def GetResult(self):
        totalSum = self.ind + sum(self.labs)
        canPass = self.dictionary["need_points"] <= totalSum
        return totalSum, canPass


def task2_example():
    data = {
        "max_mark_for_ind": 10,
        "max_mark_for_lab": 3,
        "labs_count": 3,
        "need_points": 17
    }
    sm = StudentMarks("Ihor Voloshyn", data)
    for i in range(3):
        sm.AddLab(3)
    sm.AddInd(10)
    print(*sm.GetResult())
