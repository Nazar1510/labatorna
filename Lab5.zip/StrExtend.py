class StrExtend(str):
    def __init__(self, s):
        self.s = s

    def IsPalindrom(self):
        return self.s[::] == self.s[::-1]

    def IsRepeating(self):
        count = {}
        for s in self.s:
            if s in count:
                count[s] += 1
            else:
                count[s] = 1
        for key in count:
            if count[key] >= 3:
                return True
        return False


def task3_example():
    s = StrExtend("1115111")
    print(s.IsRepeating())
    print(s.IsPalindrom())
