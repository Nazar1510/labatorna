from StrExtend import task3_example
from BookLibrary import task1_example
from StudentMarks import task2_example
from Cards import task4_example
from Vocabulary import task5_example
from Transport import task6_example


def main():
    task1_example()
    task2_example()
    task3_example()
    task4_example()
    task5_example()
    task6_example()


if __name__ == "__main__":
    main()
