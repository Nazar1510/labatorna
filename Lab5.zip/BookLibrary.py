class Book:
    def __init__(self, bookID, name, author, year, genre):
        self.bookId = bookID
        self.name = name
        self.author = author
        self.year = year
        self.genre = genre

    def ToString(self):
        print(f"Book name: {self.name}\tBook author: {self.author}\tYear: {self.year}\tGenre: {self.genre}")


class HomeLibrary:
    def __init__(self):
        self.getBookID = 0
        self.books = []

    def AddBook(self, book: Book):
        book.bookId = self.getBookID
        self.getBookID += 1
        self.books.append(book)

    def RemoveBook(self, bookID: int):
        bookIndex = -1
        for index in range(len(self.books)):
            if self.books[index].bookId == bookID:
                bookIndex = index
                break
        if bookIndex != -1:
            self.books.remove(self.books[bookIndex])

    def FindBookById(self, bookID: int):
        for book in self.books:
            if book.bookId == bookID:
                return book
        return "Not found"

    def FindBookByAuthor(self, author: str):
        for book in self.books:
            if book.author == author:
                return book
        return "Not found"

    def ToString(self):
        print("\n=== Current Library ===")
        for book in self.books:
            book.ToString()
        print("=== End of Library ===")


def task1_example():
    HL = HomeLibrary()
    book1 = Book(0, "Harry Potter", "J.K. Rowling", 1996, "Horror")
    book2 = Book(0, "Harry Potter 2", "J.K. Rowling", 1997, "Horror")
    HL.AddBook(book1)
    HL.AddBook(book2)
    HL.ToString()
    HL.RemoveBook(1)
    HL.ToString()

    HP1: Book = HL.FindBookByAuthor("J.K. Rowling")
    HP1.ToString()
